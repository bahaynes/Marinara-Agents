// Aside: pure helpers. Notes, the side thread, and the temporary message for an out-of-band question to the narrator.
// Nothing here touches the host, so it can be tested directly.

// Defaults for settings the player can change; none of these is a design limit.
export const DEFAULT_SETTINGS = Object.freeze({
  threadTurns: 20, // side-thread turns kept and sent
  connectionId: null, // null = the chat's own connection
});
const MAX_NOTES = 500;
const MAX_NOTE_CHARS = 4000;
const int = (value, fallback, min, max) =>
  Number.isInteger(value) && value >= min && value <= max ? value : fallback;

export function cleanSettings(raw) {
  const s = raw && typeof raw === "object" ? raw : {};
  return {
    threadTurns: int(s.threadTurns, DEFAULT_SETTINGS.threadTurns, 2, 200),
    connectionId: typeof s.connectionId === "string" && s.connectionId.trim() ? s.connectionId.trim().slice(0, 120) : null,
  };
}

export const emptyChat = () => ({ notes: [], thread: [] });

const newId = () => `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;

export function newNote(text, source = "user") {
  const clean = String(text ?? "").trim().slice(0, MAX_NOTE_CHARS);
  if (!clean) return null;
  return { id: newId(), text: clean, pinned: false, narrator: false, source: source === "aside" ? "aside" : "user", createdAt: new Date().toISOString() };
}

/** Apply `{text?, pinned?, narrator?}` to a note; returns the notes list. Null when the note does not exist. */
export function changeNote(notes, id, patch) {
  const note = notes.find((n) => n.id === id);
  if (!note) return null;
  if (typeof patch.text === "string" && patch.text.trim()) note.text = patch.text.trim().slice(0, MAX_NOTE_CHARS);
  if (typeof patch.pinned === "boolean") note.pinned = patch.pinned;
  if (typeof patch.narrator === "boolean") note.narrator = patch.narrator;
  return notes;
}

/** Put notes in the order of `ids`; notes not named keep their relative order after the named ones. */
export function reorderNotes(notes, ids) {
  const byId = new Map(notes.map((n) => [n.id, n]));
  const named = [...new Set(Array.isArray(ids) ? ids : [])].filter((id) => byId.has(id)).map((id) => byId.get(id));
  const rest = notes.filter((n) => !named.includes(n));
  return [...named, ...rest];
}

/** One-shot orderings for the sort menu. The result becomes the stored order; nothing keeps sorting afterwards. */
export const SORTS = Object.freeze({
  newest: (x, y) => String(y.createdAt).localeCompare(String(x.createdAt)),
  oldest: (x, y) => String(x.createdAt).localeCompare(String(y.createdAt)),
  alpha: (x, y) => x.text.localeCompare(y.text, undefined, { sensitivity: "base" }),
  pinned: (x, y) => Number(y.pinned) - Number(x.pinned), // stable: keeps the current order within each group
});

export const sortNotes = (notes, mode) => (SORTS[mode] ? [...notes].sort(SORTS[mode]) : notes);

/** Replace the text of one side-thread turn. Null when it does not exist or the text is empty. */
export function changeTurn(thread, id, text) {
  const turn = thread.find((t) => t.id === id);
  const clean = String(text ?? "").trim();
  if (!turn || !clean) return null;
  turn.text = clean;
  return thread;
}

export const addNote = (notes, note) => [note, ...notes].slice(0, MAX_NOTES);

export function newTurn(role, text) {
  return { id: newId(), role: role === "assistant" ? "assistant" : "user", text: String(text ?? ""), createdAt: new Date().toISOString() };
}

// The aside rides on the chat's real roleplay prompt, whose instructions push the model to continue the story, so
// the rules come twice: a marker up front and the hard rules last, where the model weighs them most.
const OPENING = [
  "[OUT OF CHARACTER ASIDE]",
  "The player has paused the story to ask you something directly. This is not a story turn, and nothing here becomes part of the story.",
].join("\n");

const CLOSING = [
  "Rules for this reply only:",
  "- Answer in plain out-of-character prose, speaking to the player directly. Keep it short.",
  "- Do not write any scene text, dialogue, character action or continuation of the story, not even one line. Do not start with a character's name or an action.",
  "- Use only what the story has shown. If the answer is not established, say that instead of inventing it.",
  "- The story resumes only when the player sends their next story turn.",
].join("\n");

/**
 * The one temporary user message sent with the Engine's real chat prompt (dryRun), so the prompt prefix stays the
 * chat's own and only this last message changes between asides.
 */
export function asideUserMessage({ notes, thread, question, settings }) {
  const parts = [OPENING];
  const pinned = notes.filter((n) => n.pinned).map((n) => `- ${n.text}`);
  if (pinned.length) parts.push(`<player_notes>\n${pinned.join("\n")}\n</player_notes>`);
  const earlier = thread.slice(-settings.threadTurns).map((t) => `${t.role === "user" ? "Player asked" : "You answered"}: ${t.text}`);
  if (earlier.length) parts.push(`<earlier_asides>\n${earlier.join("\n\n")}\n</earlier_asides>`);
  parts.push(`The player's question: ${String(question)}`, CLOSING);
  return parts.join("\n\n");
}

/**
 * Notes the player switched to "show to narrator": a standing author's note in every story turn, in the player's
 * order. Null when there are none, so the chat's prompt is unchanged.
 */
export function narratorNotesBlock(notes) {
  const lines = notes.filter((n) => n.narrator === true).map((n) => `- ${n.text}`);
  if (!lines.length) return null;
  return `<author_notes>\nThe player's standing notes for this story. Keep to them in every reply:\n${lines.join("\n")}\n</author_notes>`;
}
